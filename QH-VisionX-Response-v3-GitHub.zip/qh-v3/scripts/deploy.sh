#!/usr/bin/env bash
set -euo pipefail
[ -f .env ] || { echo 'Create .env from .env.example first'; exit 1; }
docker compose -f docker-compose.production.yml up -d --build
docker compose -f docker-compose.production.yml ps
