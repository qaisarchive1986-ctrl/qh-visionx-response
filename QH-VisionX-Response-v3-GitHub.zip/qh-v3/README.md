# QH VisionX Response v3
Production-ready foundation for a real-time emergency response platform.

## Stack
- Frontend: PWA, MapLibre GL, OpenStreetMap-compatible tiles
- Backend: Node.js + Express + WebSocket
- Database: PostgreSQL + PostGIS
- Cache/realtime support: Redis
- Reverse proxy: Nginx
- Deployment: Docker Compose
- CI: GitHub Actions

## Quick start
1. Copy `.env.example` to `.env` and set strong secrets.
2. Run `docker compose -f docker-compose.production.yml up -d --build`.
3. Open `http://localhost/`.

For a public deployment, put the VPS behind HTTPS and set `PUBLIC_ORIGIN` to the HTTPS domain.

## Security
Secrets are intentionally excluded. Do not commit `.env`. The demo does not contain production credentials.
